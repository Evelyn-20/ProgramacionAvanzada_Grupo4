﻿namespace Pasteleria.Models
{
    public class Class1
    {

    }
}
