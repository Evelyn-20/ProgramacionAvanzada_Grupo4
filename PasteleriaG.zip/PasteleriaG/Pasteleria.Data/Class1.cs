﻿namespace Pasteleria.Data
{
    public class Class1
    {

    }
}
