﻿namespace Pasteleria.Business
{
    public class Class1
    {

    }
}
